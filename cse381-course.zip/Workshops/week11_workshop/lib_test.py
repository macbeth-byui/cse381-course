# CSE 381 Workshop 11

import matplotlib
import skimage
import scipy
import numpy

print("Libraries installed correctly.")