# CSE 381 Workshop 2

import matplotlib.pyplot as plt
import numpy as np
import soundfile
import math

print("Libraries installed correctly.")