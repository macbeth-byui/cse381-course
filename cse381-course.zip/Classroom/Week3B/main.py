# CSE 381 REPL3B 
# Merge Sort

def Sort(data):
    pass

data = [3,1,2,6,4,5]
Sort(data)
print(data)