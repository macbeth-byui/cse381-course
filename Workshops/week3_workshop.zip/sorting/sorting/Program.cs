﻿// CSE 381 Workshop 3

using System.Text.Json;

public class Book
{
    public string title { get; set; }
    public string author { get; set; }
    public string language { get; set; }
    public int year { get; set; }

    public override string ToString()
    {
        return $"{title,-50}{author,-28}{language,-18}{year,-5}";
    }

}

class Program
{
    static async Task<List<Book>?> Get_Books()
    {
        string url = "https://raw.githubusercontent.com/benoitvallon/100-best-books/master/books.json"; 
        using HttpClient client = new HttpClient();
        try
        {
            HttpResponseMessage response = await client.GetAsync(url);
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                return JsonSerializer.Deserialize<List<Book>>(data);
            }
            Console.WriteLine($"Error reading from API: {response.StatusCode}");
            return null;
        }
        catch (HttpRequestException e)
        {
            Console.WriteLine($"Error connecting to the API: {e.Message}");
            return null;
        }
    }

    public static async Task Main(string[] args)
    {
        var books = await Get_Books();
        if (books == null)
        {
            return;
        }
        
  

        foreach (var book in books)
        {
            Console.WriteLine(book);
        }
    }
}