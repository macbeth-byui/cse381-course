# CSE 381 Workshop 4

import pygame

print("Libraries installed correctly.")