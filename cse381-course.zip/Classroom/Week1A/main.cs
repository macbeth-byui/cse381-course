// CSE 381 REPL 1A
// C# Primer



public static class Program 
{
    public static void Main (string[] args) 
    {
        Console.WriteLine ("Hello World");

        // Console.WriteLine($"x = {x} y = {y} x+y = {x+y}");


        // foreach (var i in list) {
        //     Console.WriteLine(i);
        // }

        
        // Console.WriteLine($"First: {}");
        // Console.WriteLine($"Last: {}");

        
        // foreach (var i in list2) {
        //     Console.WriteLine(i);
        // }


        // Console.WriteLine($"Area = {r.Area()}");

        
        // Console.WriteLine($"Area = {r.Area()}");


        // Console.WriteLine($"Avg: {avg}");

        
         // Console.WriteLine($"Max: {max}");

        
        // Console.WriteLine($"Max: {max}");


        // Console.WriteLine(string.Join(", ", firstHalf.ToList()));
        // Console.WriteLine(string.Join(", ", secondHalf.ToList()));

        
        // Console.WriteLine(result);
        

        // Console.WriteLine(result);

        
        // Console.WriteLine(result);

    }
}