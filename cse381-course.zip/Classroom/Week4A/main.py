# CSE 381 REPL4A 
# Quick Sort

def Sort(data):
    pass


data = [6,1,3,7,2,5,8,4]
Sort(data)
print(data)