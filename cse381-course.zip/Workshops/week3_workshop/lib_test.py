# CSE 381 Workshop 3

import requests

print("Libraries installed correctly.")