// CSE 381 REPL 1A
// C# Primer



public static class Program 
{
    public static void Main (string[] args) 
    {
        Console.WriteLine ("Hello World");

        // Console.WriteLine($"x = {x} y = {y} x+y = {x+y}");


        // foreach (var i in list) {
        //     Console.WriteLine(i);
        // }

        
        // Console.WriteLine($"First: {}");
        // Console.WriteLine($"Last: {}");

        
        // foreach (var i in list2) {
        //     Console.WriteLine(i);
        // }

        // Console.WriteLine($"First: {list2[0]}");


        // Console.WriteLine($"Area = {r.Area()}");

        
        // Console.WriteLine($"Area = {r.Area()}");


        // Console.WriteLine($"Avg: {avg4}");

        
         // Console.WriteLine($"Max: {max4}");

        
        // Console.WriteLine($"Max: {max5}");


        // Console.WriteLine(string.Join(", ", firstHalf));
        // Console.WriteLine(string.Join(", ", secondHalf));

        
        // Console.WriteLine(result);
        

        // Console.WriteLine(result);

        
        // Console.WriteLine(result);

    }
}