# CSE 381 REPL4B
# Counting Sort

def CreateEquals(data, rangeData):
    return []

def CreateOrder(equals, rangeData):
    return []

def Sort(data, rangeData):
    equals = CreateEquals(data, rangeData)
    order = CreateOrder(equals, rangeData)

    return []
    
data = [1,0,2,1,3,3,2,4,1,0]
sorted = Sort(data, 10)
for x in sorted:
    print(x)