# CSE 381 REPL 2A
# Binary Search

def search(data, target):
    pass

print(search([1,2,3,4,5,6],4))
print(search([1,2,3,4,5,6],0))